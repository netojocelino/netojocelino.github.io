<?php
  /**
   * Plugin Name: Carousel Post
   * Author: Jocelino Alves
   * Version: 1.0
   *   Plugin URI: http://netojocelino.github.io/?carouselpost
  */



  require plugin_dir_path(__FILE__) . "cpt.php";
  
  require plugin_dir_path(__FILE__) . "cti.php";
  
  
  // [carouselpost categoria="" quantidade=1 ]
  function carouselpost($attr){
    /*
    expected
      tipo: post || some
      categoria: || some

    */
    $categorias = (isset($args['categoria']) && (strlen($args['categoria']) > 0))
                        ? $args['categoria']
                        : 'projetos-realizados' ;
    
    $args = array(
      //'post_type' => 'slide',
    	'posts_per_page' => 15,
      //'numberposts' => $qtd_de_posts,
    	'offset' => 0,
    	//'category_name' => $categorias,
      //'category' => $categorias,
      'tax_query' => array(
            array(
                'taxonomy' => 'slider',
                'field' => 'slug',
                'terms' => $categorias
            )
        ),
    	'orderby' => 'post_date',
    	'order' => 'DESC',
    	'post_type' => 'slide',
    	'post_status' => 'publish',
    	'suppress_filters' => true
    );
    
    
    
    if(isset($attr['quantidade'])){
      if($attr['quantidade'] < 1) unset($args['posts_per_page']);
      else $args['post_per_page'] = intval($args['quantidade']);
    }

    $query = new WP_Query($args);
    $content = "";
    $modal = "";
    
    if($query->have_posts() && $args["posts_per_page"] >= 1){
		$content .= "<div class='row'>";
		

		while($query->have_posts()){ $query->the_post();
		  $img = get_the_post_thumbnail_url(get_the_ID(), 'full');
		  $id = get_the_ID();
		  $title = get_the_title();
		  $content_data = get_the_content();
		  

			$content .= "<div class='col-xs-4 imagem-servicos'>";
			  $content .= "<img src='".$img."' alt='".$title."' /><br>";
			  $content .= "<button class=\"btn btn-default\" type=\"button\" data-toggle=\"modal\" data-target=\"#modal".$id."\">SAIBA MAIS</button>";
			$content .= "</div>";
			
			
			$modal .= "<div id=\"modal".$id."\" class=\"modal animated zoomIn in\" role=\"dialog\" style=\"\" aria-hidden=\"false\">";
      $modal .= "\t<div class=\"modal-dialog\">";
      $modal .= "\t\t<div class=\"modal-content\">";
      $modal .= "\t\t\t<div class=\"modal-header\">";
      $modal .= "\t\t\t\t<p><button class=\"close\" type=\"button\" data-dismiss=\"modal\">×</button></p>";
      $modal .= "\t\t\t\t<h4 class=\"modal-title\">".$title."</h4>";
      $modal .= "\t\t\t\t</div>";
      $modal .= "\t\t\t\t<div class=\"modal-body\">";
      $modal .= "\t\t\t\t<p>".$content_data."</p>";
      $modal .= "\t\t\t</div>";
      $modal .= "\t\t</div>";
      $modal .= "\t</div>";
      $modal .= "</div>";
		}
		$content .= "</div>";
		//$content .= $modal;
    }
    
    if($args["posts_per_page"] > 1){
      $_base = plugin_dir_url(__DIR__);
      //$_url = $_base."css/carousel.element.css";
      $_url = $_base."css/cards.css";
      $_url2 = $_base."js/main-min.js";
      $_name = "carousel-style_";
      wp_register_style($_name."css", $_url, '1.0', null, 'all');
      wp_enqueue_style($_name."css");
      
      wp_register_style("bootstrapcss", $_base."dist/css/bootstrap.min.css?ver=3.2.0", '3.2.0', null, 'all');
      wp_enqueue_style("bootstrapcss");
      
      
      
      $content .= "<script src='{$_url2}'></script>";
    }
    
    echo $modal;
    
    return $content;
  }
  add_shortcode("carouselpost", "carouselpost");
  
  
  
function exclude_category_home_carouselpost( $query ) {
  $idx = '-'.get_cat_ID('carousel');
  $query->set( 'cat', '-3' );
  
  return $query;
}

add_filter( 'pre_get_posts', 'exclude_category_home_carouselpost' );
