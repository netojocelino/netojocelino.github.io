<?php


function catch_that_image() {
	global $post, $posts;
	$first_img = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	$first_img = false;
	if(!empty($matches[1][0])){
	    $first_img = $matches[1][0];
	}else{
	    $first_img = false;
	}

	if(empty($first_img)){ //Defines a default image
			$first_img = plugin_dir_url( __FILE__ ) .  "../assets/img/icon1.jpg";
	}
	return $first_img;
}


/*
add_shortcode( 'social-media', 'social_media' );
function social_media( $atts ) {
    extract( shortcode_atts( array(
        'numbers' => '5',
    ), $atts ) );

    $html = "<p><a href='{$atts['link']}'><i class='fa fa-{$atts['icon']}'></i></a></p>";

    return $html;
}





add_action( 'init', 'socialmedia_buttons' );
function socialmedia_buttons() {
    add_filter( "mce_external_plugins", "socialmedia_add_buttons" );
    add_filter( 'mce_buttons', 'socialmedia_register_buttons' );
}
function socialmedia_add_buttons( $plugin_array ) {
    $plugin_array['socialmedia'] = get_template_directory_uri() . '/social/plugin.js';
    return $plugin_array;
}
function socialmedia_register_buttons( $buttons ) {
    array_push( $buttons, 'instagram', 'facebook', 'lattes' );
    return $buttons;
}

*/