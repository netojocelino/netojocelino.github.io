<?php
  /**
   * Plugin Name: Carousel Post
   * Author: Jocelino Alves
   * Version: 1.1
   *   Plugin URI: http://netojocelino.github.io/?carouselpost
  */



  require plugin_dir_path(__FILE__) . "cpt.php";
  
  require plugin_dir_path(__FILE__) . "cti.php";
  
  
  
  function carouselpost($attr){
    /*
    expected
      tipo: post || some
      categoria: || some

    */
    $categorias = (isset($args['categoria']) && (strlen($args['categoria']) > 0))
                        ? $args['categoria']
                        : 'projetos-realizados' ;
    
    $args = array(
      //'post_type' => 'slide',
    	'posts_per_page' => 4,
      //'numberposts' => $qtd_de_posts,
    	'offset' => 0,
    	//'category_name' => $categorias,
      //'category' => $categorias,
      'tax_query' => array(
            array(
                'taxonomy' => 'slider',
                'field' => 'slug',
                'terms' => $categorias
            )
        ),
    	'orderby' => 'post_date',
    	'order' => 'DESC',
    	'post_type' => 'slide',
    	'post_status' => 'publish',
    	'suppress_filters' => true
    );
    
    
    
    if(isset($attr['quantidade'])){
      if($attr['quantidade'] < 1) unset($args['posts_per_page']);
      else $args['post_per_page'] = $args['quantidade'];
    }

    $query = new WP_Query($args);
    $content = "";
    if($query->have_posts()){
      $content .= '<div class="carousel-collapse">';
      $content .= '  <header class="carousel-list child-md-7">';// style="width: 100%;">';//40rem;">';
      
      
      while($query->have_posts()){ $query->the_post();
        $content .=  ' <div class="carousel-list-element" id="'.get_the_ID().'">';
        $content .=  '         <img src="'.get_the_post_thumbnail_url(get_the_ID(), 'thumbnail').'" alt="'.get_the_title().'" data-src="'.catch_that_image().'" title="'.get_the_title().'" />';
        $content .=  '         <div>';
        $content .=  '<p>'.get_the_excerpt(get_the_ID()).'</p>';
        $content .=  '         </div>';
        $content .=  '     </div>';
      }
      $content .= "  </header>";
      $content .= '<nav class="carousel-nav">';
      $content .= '      <button class="carousel-nav-control" data-control="prev">Anterior</button>';
      $content .= '      <span class="carousel-counter">0/0</span>';
      $content .= '      <button class="carousel-nav-control" data-control="next">Próximo</button>';
      $content .= '  </nav>';
      $content .= '  <section class="carousel-content">';
      $content .=  '<p class="close" style="width: 100%; text-align: right; float: right;">X</p>';
      $content .= '      <picture class="middle-page">';
      $content .= '          <img src="" />';
      $content .= '      </picture>';
      $content .= '      <article class="middle-page"></article>';
      $content .= '  </section>';
      $content .= "</div>";
    }
    
    
    $_base = plugin_dir_url(__DIR__);
    $_url = $_base."css/carousel.element.css";
    $_url2 = $_base."js/main-min.js";
    $_name = "carousel-style_";
    wp_register_style($_name."css", $_url, '1.0', null, 'all');
    wp_enqueue_style($_name."css");
    
    $content .= "<script src='{$_url2}'></script>";
    
    
    return $content;
  }
  add_shortcode("carouselpost", "carouselpost");
  
  
  
function exclude_category_home_carouselpost( $query ) {
  $idx = '-'.get_cat_ID('carousel');
  $query->set( 'cat', '-3' );
  
  return $query;
}

add_filter( 'pre_get_posts', 'exclude_category_home_carouselpost' );
