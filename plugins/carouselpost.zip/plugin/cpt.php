<?php


function slide_custom_post_type(){
    $post_opt = array(
        'name' => 'Carousel Post',
        'singular_name' => 'Slide',
        'add_new' => 'Adicionar novo',
        'all_items' => 'Todos os posts',
        'add_new_item' => 'Adicionar Item',
        'edit_item' => 'Editar Item',
        'new_item' => 'Novo Item',
        'view_item' => 'Visualizar Item',
        'search_item' => 'Procurar Post',
        'not_found' => 'Item não encontrado',
        'not_found_in_trash' => 'Sem Itens na lixeira',
        'parent_item_colon' => 'Item Pai'
    );
    $post_arg = array(
        'labels' => $post_opt,
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_icon'   => 'dashicons-media-code',
        'supports' => array(
            //'post-formats',
            'title',
            'editor',
            'thumbnail',
            'thumbnail',
            //'author',
            'excerpt'
            //'revisions'
        ),
        //'taxonomies' => array('category', 'topics'),// array('post_tag'),
        'menu_position' => 4,
        'exclude_from_search' => false
    );

    register_post_type('slide', $post_arg);
    flush_rewrite_rules();
}

add_action('init', 'slide_custom_post_type');

require plugin_dir_path(__FILE__) . "tax.php";