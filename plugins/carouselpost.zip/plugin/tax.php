<?php


add_action( 'init', 'create_slide_taxonomies', 0 );

// create two taxonomies, genres and writers for the post type "book"
function create_slide_taxonomies() {
	// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x( 'Slider', 'taxonomy general name', 'textdomain' ),
		'singular_name'     => _x( 'Slider', 'taxonomy singular name', 'textdomain' ),
		'search_items'      => __( 'Procurar Slides', 'textdomain' ),
		'all_items'         => __( 'Todos os Slides', 'textdomain' ),
		'parent_item'       => __( 'Slides pai', 'textdomain' ),
		'parent_item_colon' => __( 'Slides pai:', 'textdomain' ),
		'edit_item'         => __( 'Editar Slide', 'textdomain' ),
		'update_item'       => __( 'Atualizar slide', 'textdomain' ),
		'add_new_item'      => __( 'Adicionar Novo Slide', 'textdomain' ),
		'new_item_name'     => __( 'Novo Slide', 'textdomain' ),
		'menu_name'         => __( 'Grupo de Slide', 'textdomain' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'slide' ),
	);

	register_taxonomy( 'slider', array( 'slide' ), $args );

}