<?php
  /**
   * Plugin Name: Carousel Post
   * Author: Jocelino Alves
   * Version: 1.1
   *   Plugin URI: http://netojocelino.github.io/?carouselpost
   *   Author URI: https://bitbucket.org/netojocelino/carousel
  */

require plugin_dir_path(__FILE__) . "plugin/carousel.php";