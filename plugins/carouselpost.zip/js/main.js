'use strict';

const col = document.querySelector(".carousel-collapse");
const hd = col.querySelector(".carousel-list");
const boxes = col.querySelectorAll(".carousel-list-element");
const counter = col.querySelector(".carousel-counter");
const leng = boxes.length;

const last = { one: -1, exist: false };

counter.innerHTML = `1/${leng}`;

// função para passar os slides
Array.from(col.querySelectorAll("[data-control]")).forEach(e => {
    if(e.getAttribute("data-control") == "next"){
        e.addEventListener("click", ()=>{
            let ch = Array.from(hd.children);
            const temp = ch.shift();
            ch.push(temp);
            hd.innerHTML = "";
            ch.forEach( element => {
                hd.innerHTML += element.outerHTML;
            });
            // tratar botão de próximo
            let cont = counter.firstChild.data.split("/").map( x => +x);
            cont[0] = (cont[0] > 0) ? cont[0] - 1 : cont[0];
            cont[0] = ((cont[0]+1) % cont[1]);
            counter.innerHTML = `${cont[0]+1}/${cont[1]}`;
            // console.log(cont);
            // console.log(counter.firstChild.data);
        })
    }else if(e.getAttribute("data-control") == "prev"){
        e.addEventListener("click", ()=>{
            let ch = Array.from(hd.children);
            const temp = ch.pop();
            ch.unshift(temp);
            hd.innerHTML = "";
            ch.forEach( element => {
                hd.innerHTML += element.outerHTML;
            });

            // tratar botão de anterior
            let cont = counter.firstChild.data.split("/").map( x => +x);
            cont[0] = (cont[0] > 0) ? cont[0] - 1 : cont[0];
            cont[0] = (cont[0] < 1) ? cont[1] - 1 : cont[0] - 1;

            counter.innerHTML = `${cont[0]+1}/${cont[1]}`;
            // console.log(cont);
            // console.log(counter.firstChild.data);
        })
    }
});


// função que expande os slides
Array.from(boxes).forEach(box => {
    box.addEventListener("click", (ev) => {
        const lastOne = box.getAttribute("id");
        if(last.one <= 0){
            last.one = lastOne;
            //last.exist = true;
        } 
        
        const content = document.querySelector(".carousel-content");
        content.classList.remove("carousel-content-expands");
        content.classList.toggle("carousel-content-expands");
        const url = box.children[0].getAttribute("data-src");
        const text = box.children[1].children[0].outerHTML;
        content.querySelector("picture img").src = url;
        window.setTimeout(() => {
            content.querySelector("article").innerHTML = text;
            content.classList.add("carousel-content-expands");    
        }, 500);
        
        
        console.log(content);
    })
});